T2G04
-----
B�rbara Sofia Lopez de Carvalho Ferreira da Silva
Igor Bernardo Amorim Silveira
Julieta Pintado Jorge Frade
----
No nosso programa v�rias threads modificam a variavel que serve de contagem do numero de pessoas na sauna, existindo assim uma sec��o critica. Deste modo, e para que nao exista conflito na modifica��o do valor da vari�vel,� utilizado um mutex.
